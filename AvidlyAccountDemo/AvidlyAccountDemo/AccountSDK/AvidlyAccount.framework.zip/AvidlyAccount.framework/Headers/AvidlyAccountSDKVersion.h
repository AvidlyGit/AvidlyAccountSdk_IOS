//
//  AvidlyAccountSDKVersion.h
//  AvidlyAccountSDK
//
//  Created by steve on 2019/1/24.
//  Copyright © 2019 Avidly Technology Co.,Ltd. All rights reserved.
//

#define AvidlyAccountSDK_Version @"1001"
